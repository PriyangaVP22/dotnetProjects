﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.CodeDom;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace sampleproj1
{
    class DbCon
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-NPEME8UL\\MYSQLSERVER;Initial Catalog=SLAproj;User ID=sa;Password=Venkat123;");


        public void Login(string @uname,string @password,string @utype)
        { 
        SqlCommand cmd = new SqlCommand("validatelogin",con);
        cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@uname", uname);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@utype", utype);
            SqlDataReader reader = cmd.ExecuteReader();
            int uid = 0;
            while (reader.Read())
            {
                uid = Convert.ToInt32( reader["uid"]);
            }
            if (uid == 0)
            {
                MessageBox.Show("invalid UID/PASSWORD");
            }
            else
            {
                if (utype == "User")
                {
                    MDIUser user = new MDIUser();
                    user.Show();
                }
                else if (utype == "Admin")
                {
                    MDIAdmin user = new MDIAdmin();
                    user.Show();
                }
            }
            con.Close();
            //return x;
        }
        public int InsertProduct(int @pid, string @pname, string @pdesc)
        {
            SqlCommand cmd = new SqlCommand("InsProd", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@pname", pname);
            cmd.Parameters.AddWithValue("@pdesc", pdesc);
            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }

        public int InsertSales(int pid,string pname,int mid,string mname, string spec,int unitprice, int qty, int totamt)
        {
            SqlCommand cmd = new SqlCommand("InsSales", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@pname", pname);
            cmd.Parameters.AddWithValue("@mid", mid);
            cmd.Parameters.AddWithValue("@mname", mname);
            cmd.Parameters.AddWithValue("@spec", spec);
            cmd.Parameters.AddWithValue("@unitprice", unitprice);
            cmd.Parameters.AddWithValue("@qty", qty);
            cmd.Parameters.AddWithValue("@totamt", totamt);


            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }

        public int Insertuser(int @uid, string @uname, string @password, string @utype, string email, int mobileno)
        {
            SqlCommand cmd = new SqlCommand("Insuser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@uid", uid);
            cmd.Parameters.AddWithValue("@uname", uname);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@utype", utype);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@mobileno", mobileno);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }

        public int InsertModel(int @mid, string @mname, string @pid,string @pname,string @spec,int @uprice,int @stock)
        {
            SqlCommand cmd = new SqlCommand("Insmodel", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@mid", mid);
            cmd.Parameters.AddWithValue("@mname", mname);

            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@pname", pname);

            cmd.Parameters.AddWithValue("@spec", spec);
            cmd.Parameters.AddWithValue("@uprice", uprice);
            cmd.Parameters.AddWithValue("@stock", stock);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }
        public int UpdateProduct(int @pid, string @pname, string @pdesc)
        {
            SqlCommand cmd = new SqlCommand("UpdProd", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@pname", pname);
            cmd.Parameters.AddWithValue("@pdesc", pdesc);
            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }

        public int UpdateUser(int @uid, string @uname, string @password, string @utype, string email, int mobileno)
        {
            SqlCommand cmd = new SqlCommand("Upduser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@uid", uid);
            cmd.Parameters.AddWithValue("@uname", uname);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@utype", utype);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@mobileno", mobileno);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }
        //public int UpdateModel(int @mid,string mname)
        //{
        //    SqlCommand cmd = new SqlCommand("Updmodel", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    con.Open();
        //    cmd.Parameters.AddWithValue("@mid", mid);
        //    cmd.Parameters.AddWithValue("@mname", mname);
        //    //cmd.Parameters.AddWithValue("@pid", pid);
        //    //cmd.Parameters.AddWithValue("@pname", pname);
        //    //cmd.Parameters.AddWithValue("@spec", spec);
        //    //cmd.Parameters.AddWithValue("@uprice", uprice);
        //    //cmd.Parameters.AddWithValue("@stock", stock);


        //    int x = cmd.ExecuteNonQuery();
        //    con.Close();
        //    return x;

        //}
    public int UpdateModel(int @mid, string @mname, int @pid, string @pname, string @spec, int uprice, int @stock)
    {
        SqlCommand cmd = new SqlCommand("Updmodel", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Parameters.AddWithValue("@mid", mid);
        cmd.Parameters.AddWithValue("@mname", mname);
        cmd.Parameters.AddWithValue("@pid", pid);
        cmd.Parameters.AddWithValue("@pname", pname);
        cmd.Parameters.AddWithValue("@spec", spec);
        cmd.Parameters.AddWithValue("@uprice", uprice);
        cmd.Parameters.AddWithValue("@stock", stock);


            int x = cmd.ExecuteNonQuery();
        con.Close();
        return x;

    }
    public DataTable ViewProduct()
        {
            SqlCommand cmd = new SqlCommand("DispProd", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

        public DataTable ViewUser()
        {
            SqlCommand cmd = new SqlCommand("Dispuser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

        public DataTable ViewModel()
        {
            SqlCommand cmd = new SqlCommand("Getmodel", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }
        public DataTable ViewProductwithid(int pid)
        {
            SqlCommand cmd = new SqlCommand("DispProd1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@pid", pid);
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

        public DataTable ViewUserwithid(int uid)
        {
            SqlCommand cmd = new SqlCommand("Dispuser1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uid",uid);
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

        public DataTable ViewModelwithid(int mid)
        {
            SqlCommand cmd = new SqlCommand("Getmodel1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@mid",mid);
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }
        public int DeleteProduct(int pid)
        {
            SqlCommand cmd = new SqlCommand("DelProd1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@pid", pid);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }


        public int DeleteUser(int uid)
        {
            SqlCommand cmd = new SqlCommand("Deluser1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@uid", uid);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }
        public int DeleteModel(int mid)
        {
            SqlCommand cmd = new SqlCommand("Delmodel", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@mid", mid);

            int x = cmd.ExecuteNonQuery();
            con.Close();
            return x;

        }

        public DataTable DailyReport()
        {
            SqlCommand cmd = new SqlCommand("DailyRpt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }
        public DataTable SalesReport(DateTime f,DateTime t)
        {
            SqlCommand cmd = new SqlCommand("SalesRpt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fdate", f);
            cmd.Parameters.AddWithValue("@tdate", t);

            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

        public DataTable ProductReport(int pid)
        {
            SqlCommand cmd = new SqlCommand("ProductRpt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@pid", pid);

            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }


        public DataTable ModelReport(int mid)
        {
            SqlCommand cmd = new SqlCommand("ModelRpt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@mid", mid);

            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;

        }

    }
}