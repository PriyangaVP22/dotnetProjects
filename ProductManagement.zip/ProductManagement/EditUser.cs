﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sampleproj1
{
    public partial class EditUser : Form
    {
        public EditUser()
        {
            InitializeComponent();
        }
        DbCon db=new DbCon();
        public void LoadData()
        {
            DataTable dt = new DataTable();
            dt = db.ViewUser();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "uid";
        }
        public void clear()
        {
            comboBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int x = db.UpdateUser(int.Parse(comboBox1.Text), textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, int.Parse(textBox6.Text));
            MessageBox.Show(x + "User Updated");
            LoadData();
            clear();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cb = (sender as System.Windows.Forms.ComboBox);
                var selecteditem = (cb.SelectedItem as DataRowView);
                textBox2.Text = selecteditem["uname"].ToString();
                textBox3.Text = selecteditem["password"].ToString();
                textBox4.Text = selecteditem["utype"].ToString();
                textBox5.Text = selecteditem["email"].ToString();
                textBox6.Text = selecteditem["mobileno"].ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString() + "Error");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void EditUser_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
