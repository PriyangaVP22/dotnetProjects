﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sampleproj1
{
    public partial class MDIAdmin : Form
    {
        public MDIAdmin()
        {
            InitializeComponent();
        }
    

        private void aDDPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void eDITPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {  
        }

        private void dELPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void vIEWPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void MDIAdmin_Load(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            AddProduct a = new AddProduct();
            a.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            EditProduct ep = new EditProduct();
            ep.Show();

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            ViewProduct vp = new ViewProduct();
            vp.Show();
        }

        private void dELETEPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteProduct dp = new DeleteProduct();
            dp.Show();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            AddUser u = new AddUser();
            u.Show();   
           
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            EditUser eu = new EditUser();
            eu.Show();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            ViewUser vu = new ViewUser(); 
            vu.Show();
        }

        private void dELETEUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteUser ds=new DeleteUser(); 
            ds.Show();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            AddModel ad = new AddModel();   
            ad.Show();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            ViewModel vm=new ViewModel();   
            vm.Show();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            EditModel ed=new EditModel();
            ed.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void dAILYREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DailyReport dr=new DailyReport();
            
            dr.Show();
        }

        private void sALESREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesReport sr=new SalesReport();   
            sr.Show();
        }

        private void pRODUCTREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductReport pr=new ProductReport();
            pr.Show();
        }

        private void mODELREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModelReport mr=new ModelReport();
            mr.Show();
        }
    }
}
