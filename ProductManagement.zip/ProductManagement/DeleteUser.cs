﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sampleproj1
{
    public partial class DeleteUser : Form
    {
        public DeleteUser()
        {
            InitializeComponent();
        }
        DbCon db=new DbCon();
        public void LoadData()
        {
            DataTable dt = new DataTable();
            dt = db.ViewUser();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "uid";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int x = db.DeleteUser(int.Parse(comboBox1.Text));
            MessageBox.Show(x + "User Deleted");
            LoadData();

        }

        private void DeleteUser_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }
    }
}
