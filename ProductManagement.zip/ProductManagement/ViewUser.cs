﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sampleproj1
{
    public partial class ViewUser : Form
    {
        public ViewUser()
        {
            InitializeComponent();
        }
        DbCon db=new DbCon();
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewUser_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = db.ViewUser();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "uid";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = db.ViewUserwithid(int.Parse(comboBox1.Text));
            dataGridView1.DataSource = dt;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = db.ViewUser();
            dataGridView1.DataSource = dt;
        }
    }
}
