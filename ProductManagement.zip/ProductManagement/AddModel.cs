﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sampleproj1
{
    public partial class AddModel : Form
    {
        public AddModel()
        {
            InitializeComponent();
        }
        DbCon db=new DbCon();
        public void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";


        }
        public void LoadData()
        {
            DataTable dt = new DataTable();
            dt = db.ViewProduct();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "pid";
            //textBox4.Text = "";

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int x = db.InsertModel(int.Parse(textBox1.Text), textBox2.Text, comboBox1.Text,textBox4.Text,textBox5.Text,int.Parse(textBox6.Text),int.Parse(textBox7.Text));
            MessageBox.Show(x + "Product Inserted");
            clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cb = (sender as System.Windows.Forms.ComboBox);
                var selecteditem = (cb.SelectedItem as DataRowView);
                textBox4.Text = selecteditem["pname"].ToString();
                //textBox2.Text = selecteditem["pdesc"].ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString() + "Error");
            }
        }

        private void AddModel_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                var cb = (sender as System.Windows.Forms.ComboBox);
                var selecteditem = (cb.SelectedItem as DataRowView);
                textBox4.Text = selecteditem["pname"].ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString() + "Error");
            }
        }
    }
}
