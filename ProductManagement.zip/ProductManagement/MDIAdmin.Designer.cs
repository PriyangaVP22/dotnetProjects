﻿namespace sampleproj1
{
    partial class MDIAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEPRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEMODELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.dAILYREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALESREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUCTREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mODELREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.uSERToolStripMenuItem,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1282, 27);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.dELETEPRODUCTToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(105, 24);
            this.toolStripMenuItem1.Text = "PRODUCT";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(244, 26);
            this.toolStripMenuItem3.Text = "ADD PRODUCT";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(244, 26);
            this.toolStripMenuItem4.Text = "EDIT PRODUCT";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(244, 26);
            this.toolStripMenuItem5.Text = "VIEW PRODUCT";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // dELETEPRODUCTToolStripMenuItem
            // 
            this.dELETEPRODUCTToolStripMenuItem.Name = "dELETEPRODUCTToolStripMenuItem";
            this.dELETEPRODUCTToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.dELETEPRODUCTToolStripMenuItem.Text = "DELETE PRODUCT";
            this.dELETEPRODUCTToolStripMenuItem.Click += new System.EventHandler(this.dELETEPRODUCTToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.dELETEMODELToolStripMenuItem});
            this.toolStripMenuItem2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(86, 24);
            this.toolStripMenuItem2.Text = "MODEL";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(225, 26);
            this.toolStripMenuItem9.Text = "ADD MODEL";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(225, 26);
            this.toolStripMenuItem10.Text = "EDIT MODEL";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(225, 26);
            this.toolStripMenuItem11.Text = "VIEW MODEL";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // dELETEMODELToolStripMenuItem
            // 
            this.dELETEMODELToolStripMenuItem.Name = "dELETEMODELToolStripMenuItem";
            this.dELETEMODELToolStripMenuItem.Size = new System.Drawing.Size(225, 26);
            this.dELETEMODELToolStripMenuItem.Text = "DELETE MODEL";
            // 
            // uSERToolStripMenuItem
            // 
            this.uSERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.dELETEUSERToolStripMenuItem});
            this.uSERToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.uSERToolStripMenuItem.Name = "uSERToolStripMenuItem";
            this.uSERToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.uSERToolStripMenuItem.Text = "USERS";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(206, 26);
            this.toolStripMenuItem12.Text = "ADD USER";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(206, 26);
            this.toolStripMenuItem13.Text = "EDIT USER";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(206, 26);
            this.toolStripMenuItem14.Text = "VIEW USER";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // dELETEUSERToolStripMenuItem
            // 
            this.dELETEUSERToolStripMenuItem.Name = "dELETEUSERToolStripMenuItem";
            this.dELETEUSERToolStripMenuItem.Size = new System.Drawing.Size(206, 26);
            this.dELETEUSERToolStripMenuItem.Text = "DELETE USER";
            this.dELETEUSERToolStripMenuItem.Click += new System.EventHandler(this.dELETEUSERToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dAILYREPORTToolStripMenuItem,
            this.sALESREPORTToolStripMenuItem,
            this.pRODUCTREPORTToolStripMenuItem,
            this.mODELREPORTToolStripMenuItem});
            this.toolStripMenuItem6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(100, 24);
            this.toolStripMenuItem6.Text = "REPORTS";
            // 
            // dAILYREPORTToolStripMenuItem
            // 
            this.dAILYREPORTToolStripMenuItem.Name = "dAILYREPORTToolStripMenuItem";
            this.dAILYREPORTToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.dAILYREPORTToolStripMenuItem.Text = "DAILY REPORT";
            this.dAILYREPORTToolStripMenuItem.Click += new System.EventHandler(this.dAILYREPORTToolStripMenuItem_Click);
            // 
            // sALESREPORTToolStripMenuItem
            // 
            this.sALESREPORTToolStripMenuItem.Name = "sALESREPORTToolStripMenuItem";
            this.sALESREPORTToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.sALESREPORTToolStripMenuItem.Text = "SALES  REPORT";
            this.sALESREPORTToolStripMenuItem.Click += new System.EventHandler(this.sALESREPORTToolStripMenuItem_Click);
            // 
            // pRODUCTREPORTToolStripMenuItem
            // 
            this.pRODUCTREPORTToolStripMenuItem.Name = "pRODUCTREPORTToolStripMenuItem";
            this.pRODUCTREPORTToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.pRODUCTREPORTToolStripMenuItem.Text = "PRODUCT  REPORT";
            this.pRODUCTREPORTToolStripMenuItem.Click += new System.EventHandler(this.pRODUCTREPORTToolStripMenuItem_Click);
            // 
            // mODELREPORTToolStripMenuItem
            // 
            this.mODELREPORTToolStripMenuItem.Name = "mODELREPORTToolStripMenuItem";
            this.mODELREPORTToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.mODELREPORTToolStripMenuItem.Text = "MODEL REPORT";
            this.mODELREPORTToolStripMenuItem.Click += new System.EventHandler(this.mODELREPORTToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem7.ForeColor = System.Drawing.Color.Crimson;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(62, 24);
            this.toolStripMenuItem7.Text = "EXIT";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // MDIAdmin
            // 
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1282, 523);
            this.Controls.Add(this.menuStrip2);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip2;
            this.Name = "MDIAdmin";
            this.Load += new System.EventHandler(this.MDIAdmin_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDMODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITMODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELMODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWMODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailySalesRPTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productWiseRPTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modelWiseRPTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateBetween2DatesRPTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem dELETEPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem dELETEMODELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem dELETEUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem dAILYREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALESREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mODELREPORTToolStripMenuItem;
    }
}