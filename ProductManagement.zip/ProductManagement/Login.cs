﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Controls;

namespace sampleproj1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Dictionary<string, string> comboSource = new Dictionary<string, string>();
            comboSource.Add("1", "User");
            comboSource.Add("2", "Admin");

            comboBox1.DataSource = new BindingSource(comboSource, null);
            comboBox1.DisplayMember = "Value";
            comboBox1.ValueMember = "Key";
        }
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-NPEME8UL\\MYSQLSERVER;Initial Catalog=SLAproj;User ID=sa;Password=Venkat123;");

        DbCon db = new DbCon();     
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            string comboBox = ((KeyValuePair<string, string>)comboBox1.SelectedItem).Value;
            if ((textBox1.Text != "" && textBox2.Text != ""&& comboBox !=""))
            {
                db.Login(textBox1.Text, textBox2.Text, comboBox);
               
            }
            else
            {
                MessageBox.Show("Invalid");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clear();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
