﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sampleproj1
{
    public partial class EditModel : Form
    {

public EditModel()
        {
            InitializeComponent();
        }
        DbCon db=new DbCon();
        public void LoadData()
        {
            DataTable dt = new DataTable();
            dt = db.ViewModel();
            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "mid";
            
        } 
        
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //LoadData();

            try
            {
                var cb = (sender as System.Windows.Forms.ComboBox);
                var selecteditem = (cb.SelectedItem as DataRowView);
                textBox2.Text = selecteditem["mname"].ToString();
                textBox1.Text = selecteditem["pid"].ToString();
                textBox4.Text = selecteditem["pname"].ToString();
                textBox5.Text= selecteditem["spec"].ToString();
                textBox6.Text= selecteditem["uprice"].ToString();
                textBox7.Text = selecteditem["stock"].ToString();
                //textBox1.Text.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString() + "Error");
            }
        }
       
        public void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox7.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        } 
        public void LoadData1()
        {
            

        }

        private void EditModel_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

       

        private void button1_Click_1(object sender, EventArgs e)
        {
            int x = db.UpdateModel(
            int.Parse(comboBox2.Text),
            textBox2.Text, 
            int.Parse(textBox1.Text),
            textBox4.Text,
            textBox5.Text, 
            int.Parse(textBox6.Text), 
            int.Parse(textBox7.Text));
            MessageBox.Show(x + "Model Updated");
            LoadData();
            clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
           
        }
    }
}
